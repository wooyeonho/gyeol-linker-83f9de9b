# GYEOL × OpenClaw 통합 — Devin 지시서
## 진짜 OpenClaw 오픈소스를 써서 전부 다시 만들기

레포: https://github.com/wooyeonho/gyeol-linker-83f9de9b

---

## 핵심 문제

지금까지 OpenClaw 오픈소스를 **하나도 안 쓰고** 있음.
Devin이 OpenClaw 대신 커스텀 Python 서버(`openclaw-server/`)를 직접 만들었는데,
그것도 어디에도 배포 안 해서 **모든 기능이 죽어있음**.

OpenClaw (https://github.com/openclaw/openclaw) = 68K+ stars 오픈소스 AI 에이전트.
Telegram, Heartbeat, 스킬 실행, 메시지 라우팅을 **이미 다 해줌**.
우리가 직접 만들 필요 없음. OpenClaw에 GYEOL 스킬만 올리면 됨.

---

## 올바른 아키텍처

```
┌─────────────────────────────────────────────────┐
│              사용자                               │
│  ┌──────────────┐      ┌──────────────┐          │
│  │ GYEOL 웹 UI  │      │  Telegram    │          │
│  │ (Vercel)     │      │  봇          │          │
│  └──────┬───────┘      └──────┬───────┘          │
│         │                      │                  │
│         │                      │                  │
│         ▼                      ▼                  │
│  ┌──────────────┐    ┌────────────────────────┐  │
│  │ Next.js API  │    │  OpenClaw Gateway      │  │
│  │ → Groq 직접  │    │  (Fly.io, 24/7)        │  │
│  │   호출       │    │                        │  │
│  └──────┬───────┘    │  ■ 텔레그램 봇 (내장)  │  │
│         │            │  ■ Heartbeat (내장)     │  │
│         │            │  ■ 스킬 실행 (내장)     │  │
│         │            │  ■ 메모리 (내장)        │  │
│         │            │  ■ 샌드박스 (내장)      │  │
│         │            │                        │  │
│         │            │  GYEOL 커스텀 스킬:     │  │
│         │            │  ├─ supabase-sync      │  │
│         │            │  ├─ personality-evolve  │  │
│         │            │  ├─ learner (RSS)       │  │
│         │            │  ├─ proactive (먼저말걸기)│  │
│         │            │  └─ security           │  │
│         │            └────────────┬───────────┘  │
│         │                         │               │
│         └────────────┬────────────┘               │
│                      ▼                            │
│  ┌────────────────────────────────────────────┐  │
│  │            Supabase (공유 DB)               │  │
│  │  대화 · 성격 · 활동로그 · 매칭 · 마켓       │  │
│  └────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘

핵심:
- OpenClaw = 텔레그램 + 자율 활동 (heartbeat, 스킬)
- Next.js = 웹 채팅 (Groq 직접 호출)
- Supabase = 공유 데이터 (양쪽 다 읽고 씀)
```

---

## 작업 순서

### TASK 1: 커스텀 Python 서버 삭제

`openclaw-server/` 디렉토리는 더 이상 필요 없음. OpenClaw이 대체함.
삭제하거나 `_deprecated/` 로 이동.

```bash
mv openclaw-server/ _deprecated-openclaw-server/
```

### TASK 2: 실제 OpenClaw 배포 준비

첨부된 `openclaw-deploy/` 폴더 내용을 레포에 추가:

```
openclaw-deploy/
├── Dockerfile              → 레포 루트 또는 openclaw/ 폴더
├── fly.toml                → 레포 루트 또는 openclaw/ 폴더
├── openclaw.json           → OpenClaw 설정 (Groq, Telegram)
└── workspace/
    ├── AGENT.md            → GYEOL 성격 (시스템 프롬프트)
    ├── HEARTBEAT.md        → 자율 행동 체크리스트
    └── skills/
        ├── gyeol-supabase-sync/SKILL.md
        ├── gyeol-personality-evolve/SKILL.md
        ├── gyeol-learner/SKILL.md
        ├── gyeol-proactive/SKILL.md
        └── gyeol-security/SKILL.md
```

### TASK 3: Fly.io에 실제 OpenClaw 배포

```bash
cd openclaw-deploy  # (또는 레포에 넣은 위치)

# Fly.io 앱 생성
fly launch --no-deploy

# 볼륨 생성 (OpenClaw 데이터 영속화)
fly volumes create openclaw_data --region nrt --size 1

# API 키 설정
fly secrets set GROQ_API_KEY="실제_Groq키"
fly secrets set TELEGRAM_BOT_TOKEN="실제_텔레그램봇토큰"
fly secrets set AUTH_PASSWORD="관리자비밀번호"
fly secrets set SUPABASE_URL="실제_Supabase_URL"
fly secrets set SUPABASE_SERVICE_KEY="실제_Supabase_서비스키"

# 배포!
fly deploy
```

### TASK 4: OpenClaw 초기 설정

배포 후 온보딩 실행:

```bash
# OpenClaw CLI 접속
fly ssh console

# 온보딩 (이미 config.json이 있으므로 대부분 자동)
# Model: groq/llama-3.3-70b-versatile
# Channel: Telegram (토큰은 이미 env에 있음)
# Agent name: GYEOL
```

또는 coollabsio 이미지 사용 시 env 변수로 자동 설정됨.

### TASK 5: 텔레그램 봇 연결

OpenClaw에 텔레그램이 내장되어 있으므로:

1. @BotFather에서 봇 토큰 발급 (이미 있으면 스킵)
2. `TELEGRAM_BOT_TOKEN` env에 설정 (TASK 3에서 이미 함)
3. 페어링:
```bash
fly ssh console
# OpenClaw 내부에서:
openclaw channels login
# 또는:
openclaw pairing approve telegram <CODE>
```

4. 봇에게 메시지 보내서 테스트

### TASK 6: 프론트엔드 브랜딩 수정

첨부된 `frontend/` 파일들로 교체:

```
frontend/activity-page.tsx      → app/activity/page.tsx
frontend/settings-page.tsx      → app/settings/page.tsx
frontend/admin-status-route.ts  → app/api/admin/status/route.ts
frontend/agent-status-route.ts  → app/api/agent/status/route.ts
frontend/chat-route.ts          → app/api/chat/route.ts
frontend/activity-route.ts      → app/api/activity/route.ts
frontend/types.ts               → lib/gyeol/types.ts
frontend/ecosystem.config.js    → server/ecosystem.config.js
```

유저 화면의 "OpenClaw" → "GYEOL 서버" 전부 교체됨.

### TASK 7: Vercel 환경변수 업데이트

Vercel 프로젝트에 환경변수 설정/업데이트:

```
OPENCLAW_GATEWAY_URL = https://gyeol-openclaw.fly.dev
GROQ_API_KEY = 실제키
```

웹 채팅은 Groq 직접 호출 (OpenClaw 안 거침).
활동 피드, 서버 상태는 OpenClaw gateway에서 가져옴.

### TASK 8: 커밋 & PR

```bash
git checkout -b feat/real-openclaw-integration

# 커스텀 서버 삭제/이동
git rm -r openclaw-server/  # 또는 mv

# OpenClaw 배포 파일 추가
git add openclaw-deploy/

# 브랜딩 수정 파일
git add app/activity/page.tsx
git add app/settings/page.tsx
git add app/api/admin/status/route.ts
git add app/api/agent/status/route.ts
git add app/api/chat/route.ts
git add app/api/activity/route.ts
git add lib/gyeol/types.ts

git commit -m "feat: 실제 OpenClaw 오픈소스 통합 + 커스텀 서버 제거

BREAKING: openclaw-server/ (커스텀 Python) 제거
NEW: openclaw-deploy/ (실제 OpenClaw 오픈소스)

OpenClaw 통합:
- coollabsio/openclaw Docker 이미지 기반
- GYEOL AGENT.md (한국어 시스템 프롬프트)
- 커스텀 스킬 5개 (supabase, personality, learner, proactive, security)
- Fly.io 배포 (24/7 상시, nrt 리전)
- 텔레그램 봇 내장 연동

브랜딩:
- 유저 화면 'OpenClaw' → 'GYEOL 서버' 교체

아키텍처 변경:
- OpenClaw = 텔레그램 + 자율 활동 (heartbeat, 스킬)
- Next.js = 웹 채팅 (Groq 직접)
- Supabase = 공유 데이터"

git push origin feat/real-openclaw-integration
```

---

## 검증 체크리스트

```
□ fly status → 서버 running
□ https://gyeol-openclaw.fly.dev/healthz → OK
□ 텔레그램 봇에게 "안녕" → AI 응답 (한국어, 한자 없이)
□ 텔레그램 봇 /status → 상태 표시
□ gyeol-ai.vercel.app → Void 화면 + 채팅 가능
□ 웹 채팅 "안녕" → AI 응답 (Groq 직접)
□ fly logs → heartbeat 스킬 실행 로그
□ fly logs → RSS 학습 로그
□ Supabase → gyeol_autonomous_logs에 데이터 쌓임
□ 활동 피드 페이지 → 활동 표시
```

---

## OpenClaw이 이미 해주는 것 (직접 만들 필요 없음!)

| 기능 | OpenClaw 내장 | 이전 커스텀 서버 |
|------|-------------|---------------|
| 텔레그램 봇 | ✅ 내장 | 직접 구현 (안됨) |
| Heartbeat | ✅ 내장 | 직접 구현 (안돌아감) |
| 메시지 라우팅 | ✅ 내장 | 직접 구현 |
| 스킬 실행 | ✅ 내장 (SKILL.md) | 직접 구현 |
| 샌드박스 | ✅ 내장 (Docker) | 없음 |
| 메모리/대화기록 | ✅ 내장 | 직접 구현 |
| 웹 UI | ✅ 내장 (:18789) | 없음 |
| WhatsApp | ✅ 내장 | 없음 |
| Discord | ✅ 내장 | 없음 |
| 브라우저 제어 | ✅ 내장 | 없음 |
| 파일 조작 | ✅ 내장 | 없음 |
| 쉘 명령 실행 | ✅ 내장 | 없음 |

## 우리가 만드는 것 (GYEOL 고유)

| 기능 | 구현 방식 |
|------|----------|
| Void 비주얼 (빛의 점) | Next.js 프론트엔드 |
| 성격 진화 엔진 | OpenClaw 스킬 (SKILL.md) |
| AI 소셜 매칭 | Next.js + Supabase |
| 스킨/스킬 마켓 | Next.js + Supabase |
| Supabase 동기화 | OpenClaw 스킬 (SKILL.md) |
| 웹 채팅 UI | Next.js → Groq 직접 |

---

## 파일 매핑

| 첨부 파일 | → 레포 위치 |
|-----------|------------|
| `openclaw-deploy/Dockerfile` | `openclaw-deploy/Dockerfile` (새 폴더) |
| `openclaw-deploy/fly.toml` | `openclaw-deploy/fly.toml` |
| `openclaw-deploy/openclaw.json` | `openclaw-deploy/openclaw.json` |
| `openclaw-deploy/workspace/AGENT.md` | `openclaw-deploy/workspace/AGENT.md` |
| `openclaw-deploy/workspace/HEARTBEAT.md` | `openclaw-deploy/workspace/HEARTBEAT.md` |
| `openclaw-deploy/workspace/skills/*/SKILL.md` | 각 스킬 폴더 |
| `frontend/activity-page.tsx` | `app/activity/page.tsx` |
| `frontend/settings-page.tsx` | `app/settings/page.tsx` |
| `frontend/admin-status-route.ts` | `app/api/admin/status/route.ts` |
| `frontend/agent-status-route.ts` | `app/api/agent/status/route.ts` |
| `frontend/chat-route.ts` | `app/api/chat/route.ts` |
| `frontend/activity-route.ts` | `app/api/activity/route.ts` |
| `frontend/types.ts` | `lib/gyeol/types.ts` |
| `frontend/ecosystem.config.js` | `server/ecosystem.config.js` |

---

## 참고: OpenClaw 공식 문서

- GitHub: https://github.com/openclaw/openclaw
- Docker 설치: https://docs.openclaw.ai/install/docker
- 스킬 만들기: 워크스페이스의 `skills/<name>/SKILL.md`
- 설정 포맷: `~/.openclaw/openclaw.json`
- 채널 연결: `openclaw channels login`
- coollabsio 이미지: https://github.com/coollabsio/openclaw
  (env 변수로 자동 설정, Fly.io 배포에 편함)
